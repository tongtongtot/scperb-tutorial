python3 -W ignore st_gan.py --dataset pbmc
python3 -W ignore st_gan.py --dataset study