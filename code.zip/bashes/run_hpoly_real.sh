python3 -W ignore spaperb.py --model_name Endocrine --exclude_celltype Endocrine --data hpoly
python3 -W ignore spaperb.py --model_name Enterocyte --exclude_celltype Enterocyte --data hpoly
python3 -W ignore spaperb.py --model_name Enterocyte.Progenitor --exclude_celltype Enterocyte.Progenitor --data hpoly
python3 -W ignore spaperb.py --model_name Goblet --exclude_celltype Goblet --data hpoly
python3 -W ignore spaperb.py --model_name Stem --exclude_celltype Stem --data hpoly
python3 -W ignore spaperb.py --model_name TA --exclude_celltype TA --data hpoly
python3 -W ignore spaperb.py --model_name TA.Early --exclude_celltype TA.Early --data hpoly
python3 -W ignore spaperb.py --model_name Tuft --exclude_celltype Tuft --data hpoly